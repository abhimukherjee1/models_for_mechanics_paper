
from cc3d import CompuCellSetup        

from Hackathon1Steppables import TrackCellCOMSteppable
from Hackathon1Steppables import Hackathon1Steppable
from Hackathon1Steppables import WaveSteppable

CompuCellSetup.register_steppable(steppable=TrackCellCOMSteppable(frequency=1))
CompuCellSetup.register_steppable(steppable=Hackathon1Steppable(frequency=1))
CompuCellSetup.register_steppable(steppable=WaveSteppable(frequency=1))

CompuCellSetup.run()
