from cc3d import CompuCellSetup
from cc3d.cpp.PlayerPython import *
from cc3d.core.PySteppables import *

class TrackCellCOMSteppable(SteppableBasePy):
    def __init__(self,frequency=1):
        SteppableBasePy.__init__(self,frequency)
                       
        
    def start(self):
        
        self.pos=np.zeros(100000)
        self.vel=np.zeros(100000)
        self.pos2=np.zeros(100000)
        self.vel2=np.zeros(100000)
        self.pos3=np.zeros(100000)
        self.vel3=np.zeros(100000)
        
        self.create_scalar_field_cell_level_py("AvgCellVelocity")
        
        
    def step(self,mcs):        
        # Initialize local variables
        CellVel = 0
        CellVel_FGF = 0
        CellVel_WNT = 0
        avgCellVel = 0
        avg_CellVel_FGF = 0
        avg_CellVel_WNT = 0
        counter = 0
        counter_FGF = 0
        counter_WNT = 0
        migrate_list = []
        
        for cell in self.cell_list:
            startxCOM = cell.xCOM
            self.pos[0]=startxCOM  #Initializing self.pos matrix of all cells with respective initial cell xCOM positions
                    
        # Tracking the center of each cell every MCS
        if mcs < 100:
            for cell in self.cell_list_by_type(self.FGFLAT):
                self.pos[mcs]=cell.xCOM
        if mcs >= 100:
            migrate_list = []
            for cell in self.cell_list_by_type(self.FGFLAT):
                self.pos[mcs]=cell.xCOM
                self.vel[mcs]=(self.pos[mcs] - self.pos[mcs-10])/10
                migrate_list.append(self.vel[mcs])
                
                CellVel += self.vel[mcs]  #Sum over velocities of all cells
                counter += 1  #Count the number of cells in this system
                
                avgCellVel = self.vel[mcs]  #Calculate variation of cell velocity from global average                  
                

class Hackathon1Steppable(SteppableBasePy):

    def __init__(self,frequency=1):

        SteppableBasePy.__init__(self,frequency)

    def start(self):
        clusterid_fgf = 0
        for cell in self.cell_list_by_type(self.FGFAPI):
            clusterid_fgf = cell.clusterId
            for cell2 in self.cell_list_by_type(self.FGFLAT):                
                if cell2.xCOM <= cell.xCOM+5 and cell2.xCOM >= cell.xCOM-5:                    
                    self.reassign_cluster_id(cell2, clusterid_fgf)
            for cell3 in self.cell_list_by_type(self.FGFBAS):
                if cell3.xCOM <= cell.xCOM+5 and cell3.xCOM >= cell.xCOM-5:
                    self.reassign_cluster_id(cell3, clusterid_fgf)    
        
        for cell in self.cell_list_by_type(self.WNT):
                cell.fluctAmpl = 50
            
                for neighbor, csa in self.get_cell_neighbor_data_list(cell):
                    if neighbor and neighbor.type==self.ECM:
                        cell.lambdaVecX = -2.0  # force component pointing along X axis - towards positive X's
                        cell.lambdaVecY = 0.0  # force component pointing along Y axis - towards negative Y's
                        cell.lambdaVecZ = 0.0  # force component pointing along Z axis    
        
        for cell in self.cell_list_by_type(self.FGFBAS):
                        cell.fluctAmpl = 30
                        
                        cell.lambdaVecX = -3.0  # force component pointing along X axis - towards positive X's
                        cell.lambdaVecY = 0.0  # force component pointing along Y axis - towards negative Y's
                        cell.lambdaVecZ = 0.0  # force component pointing along Z axis                    
            
        for cell in self.cell_list_by_type(self.SHEATH):
                        cell.fluctAmpl = 50
                        
                        cell.lambdaVecX = -1.0  # force component pointing along X axis - towards positive X's
                        cell.lambdaVecY = 0.0  # force component pointing along Y axis - towards negative Y's
                        cell.lambdaVecZ = 0.0  # force component pointing along Z axis         
                    
        
        
    def step(self,mcs):
        # To stall the primordium, uncomment the lines below. Wnt cells will then slow significantly between 5000 and 10000 mcs before speeding up again
        # if mcs <= 5000:
            for cell in self.cell_list_by_type(self.WNT):
                cell.fluctAmpl = 50
            
                for neighbor, csa in self.get_cell_neighbor_data_list(cell):
                    if neighbor and neighbor.type==self.ECM:
                        cell.lambdaVecX = -2.0  # force component pointing along X axis - towards positive X's
                        cell.lambdaVecY = 0.0  # force component pointing along Y axis - towards negative Y's
                        cell.lambdaVecZ = 0.0  # force component pointing along Z axis    
        
        # if mcs > 5000 and mcs <= 10000:
            # for cell in self.cell_list_by_type(self.WNT):
                # cell.fluctAmpl = 10
            
                # for neighbor, csa in self.get_cell_neighbor_data_list(cell):
                    # if neighbor and neighbor.type==self.ECM:
                        # cell.lambdaVecX = -0.1  # force component pointing along X axis - towards positive X's
                        # cell.lambdaVecY = 0.0  # force component pointing along Y axis - towards negative Y's
                        # cell.lambdaVecZ = 0.0  # force component pointing along Z axis    
        
        # if mcs > 10000:
            # for cell in self.cell_list_by_type(self.WNT):
                # cell.fluctAmpl = 50
            
                # for neighbor, csa in self.get_cell_neighbor_data_list(cell):
                    # if neighbor and neighbor.type==self.ECM:
                        # cell.lambdaVecX = -2.0  # force component pointing along X axis - towards positive X's
                        # cell.lambdaVecY = 0.0  # force component pointing along Y axis - towards negative Y's
                        # cell.lambdaVecZ = 0.0  # force component pointing along Z axis               
                    
    # def finish(self):
        # """
        # Finish Function is called after the last MCS
        # """

    # def on_stop(self):
        # # this gets called each time user stops simulation
        # return  
    

class WaveSteppable(SteppableBasePy):
    def __init__(self, frequency=1):
        SteppableBasePy.__init__(self, frequency)        

    def start(self):
        
        for cell in self.cell_list_by_type(self.WNT):
            #cell.dict['constrict']=0
            for neighbor, csa in self.get_cell_neighbor_data_list(cell):
                if neighbor and neighbor.type == self.WNT:
                    # Make sure FocalPointPlacticity plugin is loaded
                    # Arguments are:
                    # initiator: CellG, initiated: CellG, lambda_distance: float, target_distance: float, max_distance: float
                    link = self.focalPointPlasticityPlugin.createFocalPointPlasticityLink(cell, neighbor, 5, 10, 200)                         
        
        for cell in self.cell_list_by_type(self.FGFLAT):
            #cell.dict['constrict']=0
            for neighbor, csa in self.get_cell_neighbor_data_list(cell):
                if neighbor and neighbor.type == self.FGFLAT:
                    # Make sure FocalPointPlacticity plugin is loaded
                    # Arguments are:
                    # initiator: CellG, initiated: CellG, lambda_distance: float, target_distance: float, max_distance: float
                    link = self.focalPointPlasticityPlugin.createFocalPointPlasticityLink(cell, neighbor, 5, 10, 100)
        
        # for cell in self.cell_list_by_type(self.FGFAPI):
            # #cell.dict['constrict']=0
            # for neighbor, csa in self.get_cell_neighbor_data_list(cell):
                # if neighbor and neighbor.type == self.FGFAPI:
                    # # Make sure FocalPointPlacticity plugin is loaded
                    # # Arguments are:
                    # # initiator: CellG, initiated: CellG, lambda_distance: float, target_distance: float, max_distance: float
                    # link = self.focalPointPlasticityPlugin.createFocalPointPlasticityLink(cell, neighbor, 50000, 1, 10)
                    
        self.list_ids=[]
        self.list_del=[]
        self.counter=1
        for cell in self.cell_list_by_type(self.FGFAPI):
            self.list_ids.append(cell.id)
    
    def step(self,mcs):
        for cell in self.cell_list_by_type(self.FGFLAT):
            #cell.dict['constrict']=0
            for neighbor, csa in self.get_cell_neighbor_data_list(cell):
                if neighbor and neighbor.type == self.FGFLAT:
                    # Make sure FocalPointPlacticity plugin is loaded
                    # Arguments are:
                    # initiator: CellG, initiated: CellG, lambda_distance: float, target_distance: float, max_distance: float
                    link = self.focalPointPlasticityPlugin.createFocalPointPlasticityLink(cell, neighbor, 10, 8, 100)        
        
    def finish(self):
        # this function may be called at the end of simulation - used very infrequently though
        return

    def on_stop(self):
        # this gets called each time user stops simulation
        return    
        